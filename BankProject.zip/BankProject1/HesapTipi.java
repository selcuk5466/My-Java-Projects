package BankProject1;

public enum HesapTipi {

    CHECKING,   // vadesiz hesap
    SAVINGS,    // tasarruf hesabı
    CREDIT      // kredi hesabı
}
