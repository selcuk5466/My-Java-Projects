package BankProject1;

public class BankaMain {
    public static void main(String[] args) {

        BankaSimülasyonu musteri=new BankaSimülasyonu();
        musteri.run();

    }
}
