package BankProject1;

public class Hesap {
    private int accountId;
    private int customerId;
    private double balance;
    private HesapTipi hesapTipi;
    private static int accauntSayac = 9000;

    // CONSTRUCTORS
    public Hesap() {
        this.accountId = accauntSayac++;
        setCustomerId(customerId);
        setHesapTipi(hesapTipi);
        this.balance = 0.0;
    }

    public static int getAccauntSayac() {
        return accauntSayac;
    }

    public int getAccountId() {
        return accountId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public HesapTipi getHesapTipi() {
        return hesapTipi;
    }

    public void setHesapTipi(HesapTipi hesapTipi) {
        this.hesapTipi = hesapTipi;
    }

    public void depositToAmount(double amount) {
        if (amount>0)
            this.balance=balance+amount;
        else
            System.out.println("Geçersiz bir yatırma işlemi, O dan küçük sayı girilemez.");
    }
    public void withdrawToAmount(double amount) {
        if (amount>0 && amount<balance)
            this.balance=balance-amount;
        else
            System.out.println("Geçersiz çekim emri, lütfen girdiğiniz değerin doğru olduğundan emin olun.");
    }

    @Override
    public String toString() {
        return "Hesap{" +
                "accountId=" + accountId +
                ", customerId=" + customerId +
                ", balance=" + balance +
                ", hesapTipi=" + hesapTipi +
                '}';
    }
}
