package BookProject;

import java.util.ArrayList;
import java.util.Scanner;

class OnlineKitapMagazasi {
    private ArrayList<Kitap> kitapListesi = new ArrayList<>();
    private Scanner oku = new Scanner(System.in);
    private Scanner okuSayi=new Scanner(System.in);

   public void kitapEkle(){
       System.out.println("\n--------------- KİTAP EKLEME BÖLÜMÜNE HOŞGELDİNİZ -------------");
       System.out.print("Kitap Adı: "); String kitapAdi=oku.nextLine();
       System.out.print("Yazarı: "); String yazarAdi=oku.nextLine();
       System.out.print("Yayın yılı: "); int yayinYili=okuSayi.nextInt();
       System.out.print("Fiyat: "); double fiyat=okuSayi.nextDouble();
       Kitap kitap=new Kitap(kitapAdi,yazarAdi,yayinYili,fiyat);
       kitapListesi.add(kitap);
       System.out.println("--------\nKitap başarıyla eklendi. Kitap No:" + kitap.getKitapNumarasi()+"-----------");

   }

    public void kitapSil() {
       boolean kitapVarmi=false;
        System.out.println("\n--------------- KİTAP SİLME BÖLÜMÜNE HOŞGELDİNİZ -------------");
        if (kitapListesi.isEmpty()) {
            System.out.println("----------------LİSTEDE HENÜZ KİTAP BULUNMUYOR!---------------");

        }else {
            Kitap kitap2=new Kitap();
            System.out.print("Silmek istediğiniz kitabın numarasını girin: ");
            int kitapNo = okuSayi.nextInt();
            if (kitapNo>0 && kitapNo<=kitap2.getSayac()) {
                for (Kitap kitap : kitapListesi)
                    if (kitap.getKitapNumarasi() == kitapNo) {
                        kitapListesi.remove(kitap);
                        System.out.println("-----------KİTAP BAŞARILI BİR ŞEKİLDE SİLİNDİ--------------");
                        break;
                    }
            }
            if (kitapNo>kitap2.getSayac())
                System.out.println("---------GİRİLEN NUMARAYA KAYITLI KİTAP BULUNMUYOR. ÜZGÜNÜM!-----------");
        }
    }

    public void kitapListele() {
        System.out.println("\n--------------- KİTAP LİSTELEME BÖLÜMÜNE HOŞGELDİNİZ -------------");
        if (!(kitapListesi.isEmpty())) {
            for (Kitap kitap : kitapListesi)
                System.out.println(kitap);
        }else
            System.out.println("-------------LİSTELERİMİZE HENÜZ HİÇ KİTAP KAYDEDİLMEMİŞ. ÜZGÜNÜM!---------------");
    }
}
