package BookProject;

import java.util.Scanner;

public class Runner {
    public static void main(String[] args) {

        Scanner okuSayi = new Scanner(System.in);
        OnlineKitapMagazasi kitapMagazasi=new OnlineKitapMagazasi();
        int secim;

        do
        {
            System.out.print(  "\n1 - Kitap Ekle\n" +
                               "2 - Kitap Sil\n"+
                               "3 - Kitap Listele\n"+
                               "Seçiminizi yapınız: ");   secim=okuSayi.nextInt();
            switch (secim){
                case 1: kitapMagazasi.kitapEkle(); break;
                case 2: kitapMagazasi.kitapSil(); break;
                case 3: kitapMagazasi.kitapListele(); break;
                case 0: System.out.println("Program sonlandırılıyor."); break;
                default : System.out.println("Geçersiz bir seçim yaptınız. Lütfen tekrar deneyin.\n"); break;
            }
        }while (secim!=0);
    }
}

