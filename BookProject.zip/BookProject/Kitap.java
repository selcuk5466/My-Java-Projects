package BookProject;

class Kitap {
    private int kitapNumarasi;
    private int yayinYili;
    private String yazarAdi;
    private String kitapAdi;
    private double fiyat;
    private static int sayac=1;


    public Kitap() {
        this.kitapNumarasi=sayac++;
        setKitapAdi(kitapAdi);
        setYazarAdi(yazarAdi);
        setYayinYili(yayinYili);
        setFiyat(fiyat);
    }

    public Kitap(String kitapAdi, String yazarAdi, int yayinYili, double fiyat) {
        this.kitapNumarasi=sayac++;
        setKitapAdi(kitapAdi);
        setYazarAdi(yazarAdi);
        setYayinYili(yayinYili);
        setFiyat(fiyat);
    }

    public static int getSayac() {
        return sayac;
    }

    public int getKitapNumarasi() {
        return kitapNumarasi;
    }

    public String getYazarAdi() {
        return yazarAdi;
    }

    public void setYazarAdi(String yazarAdi) {
        this.yazarAdi=yazarAdi;
    }

    public String getKitapAdi() {
        return kitapAdi;
    }

    public void setKitapAdi(String kitapAdi) {
        this.kitapAdi=kitapAdi;
    }

    public int getYayinYili() {
        return yayinYili;
    }

    public void setYayinYili(int yayinYili) {
        this.yayinYili=yayinYili;
    }

    public double getFiyat() {
        return fiyat;
    }

    public void setFiyat(double fiyat) {
        this.fiyat=fiyat;
    }

    @Override
    public String toString() {
        return "Kitap{" +
                "kitapNumarasi=" + kitapNumarasi +
                ", yayinYili=" + yayinYili +
                ", yazarAdi='" + yazarAdi + '\'' +
                ", kitapAdi='" + kitapAdi + '\'' +
                ", fiyat=" + fiyat +
                '}';
    }
}
